package customerService.bean;

import lombok.Data;

@Data
public class ChartDTO {
	private String name;
	private int[] data;
}
