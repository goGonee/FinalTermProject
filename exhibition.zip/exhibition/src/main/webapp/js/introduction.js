$(document).ready(function(){
	$('#houseImg').click(function(){
		location.href='/exhibition/main/index.do';
	});
	
});
