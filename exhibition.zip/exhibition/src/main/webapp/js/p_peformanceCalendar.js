$(document).ready(function(){
	
	//일정-공연일정-리스트로 보기
	$('#list_play').click(function(){
		location.href = "/exhibition/performance/P_performanceList.do";
	});
	
});